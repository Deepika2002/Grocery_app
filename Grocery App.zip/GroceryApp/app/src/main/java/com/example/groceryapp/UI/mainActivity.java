package com.example.groceryapp.UI;

import android.app.Activity;

public class mainActivity extends Activity {
}
